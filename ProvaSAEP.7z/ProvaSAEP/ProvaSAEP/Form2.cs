﻿using ProvaSAEP.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProvaSAEP
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public void CarregaDGV1()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea1();
        }

        public void CarregaDGV2()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea2();
        }

        public void CarregaDGV3()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea3();
        }

        public void CarregaDGV4()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea4();
        }

        public void CarregaDGV5()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea5();
        }

        public void CarregaDGV6()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea6();
        }

        public void CarregaDGV7()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea7();
        }

        public void CarregaDGV8()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea8();
        }

        public void CarregaDGV9()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea9();
        }


        public void CarregaDGV10()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea10();
        }

        public void CarregaDGV11()
        {
            Estoque saldo = new Estoque();
            dgvArea.DataSource = saldo.ListaArea11();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (lblArea.Text == "1")
            {
                CarregaDGV1();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }

            }
            else if (lblArea.Text == "2")
            {
                CarregaDGV2();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "3")
            {
                CarregaDGV3();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "4")
            {
                CarregaDGV4();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "5")
            {
                CarregaDGV5();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "6")
            {
                CarregaDGV6();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "7")
            {
                CarregaDGV7();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "8")
            {
                CarregaDGV8();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "9")
            {
                CarregaDGV9();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "10")
            {
                CarregaDGV10();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
            else if (lblArea.Text == "11")
            {
                CarregaDGV11();
                if (dgvArea.Rows.Count == 0)
                {
                    MessageBox.Show("Não existem automóveis nesta área!");
                    this.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 abrir = new Form3(textBox1.Text);
            abrir.ShowDialog();
        }
    }
}

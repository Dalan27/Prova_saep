﻿using ProvaSAEP.Classes.ProvaSAEP.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvaSAEP.Classes
{
    public class Concessionaria
    {
        public int id { get; set; }
        public string concessionária { get; set; }

        public Concessionaria(int id, string nome)
        {
            this.id = id;
            this.concessionária = nome;

        }

        public Concessionaria()
        {
        }

        public List<Concessionaria> ListaConcessionarias()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Concessionaria> li = new List<Concessionaria>();
            string sql = "SELECT * FROM concessionarias";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Concessionaria m = new Concessionaria();
                m.id = (int)dr["id"];
                m.concessionária = dr["concessionária"].ToString();
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }
    }
}

    

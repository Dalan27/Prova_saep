﻿namespace ProvaSAEP
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblModeloCarro = new System.Windows.Forms.Label();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblCodigoconcessionaria = new System.Windows.Forms.Label();
            this.lblCarro = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvConcessionaria = new System.Windows.Forms.DataGridView();
            this.dgvCliente = new System.Windows.Forms.DataGridView();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.txtCon = new System.Windows.Forms.TextBox();
            this.btnComfirmar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConcessionaria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // lblModeloCarro
            // 
            this.lblModeloCarro.AutoSize = true;
            this.lblModeloCarro.BackColor = System.Drawing.SystemColors.Control;
            this.lblModeloCarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModeloCarro.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblModeloCarro.Location = new System.Drawing.Point(12, 48);
            this.lblModeloCarro.Name = "lblModeloCarro";
            this.lblModeloCarro.Size = new System.Drawing.Size(123, 16);
            this.lblModeloCarro.TabIndex = 0;
            this.lblModeloCarro.Text = "Modelo do Carro";
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCliente.Location = new System.Drawing.Point(325, 60);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(109, 16);
            this.lblCliente.TabIndex = 1;
            this.lblCliente.Text = "Código Cliente";
            // 
            // lblCodigoconcessionaria
            // 
            this.lblCodigoconcessionaria.AutoSize = true;
            this.lblCodigoconcessionaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoconcessionaria.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCodigoconcessionaria.Location = new System.Drawing.Point(325, 120);
            this.lblCodigoconcessionaria.Name = "lblCodigoconcessionaria";
            this.lblCodigoconcessionaria.Size = new System.Drawing.Size(169, 16);
            this.lblCodigoconcessionaria.TabIndex = 2;
            this.lblCodigoconcessionaria.Text = "Código Concessionaria";
            // 
            // lblCarro
            // 
            this.lblCarro.AutoSize = true;
            this.lblCarro.Location = new System.Drawing.Point(12, 120);
            this.lblCarro.Name = "lblCarro";
            this.lblCarro.Size = new System.Drawing.Size(35, 13);
            this.lblCarro.TabIndex = 3;
            this.lblCarro.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(133, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Cliente";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(527, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Concessionaria";
            // 
            // dgvConcessionaria
            // 
            this.dgvConcessionaria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConcessionaria.Location = new System.Drawing.Point(399, 219);
            this.dgvConcessionaria.Name = "dgvConcessionaria";
            this.dgvConcessionaria.Size = new System.Drawing.Size(381, 205);
            this.dgvConcessionaria.TabIndex = 6;
            // 
            // dgvCliente
            // 
            this.dgvCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCliente.Location = new System.Drawing.Point(12, 219);
            this.dgvCliente.Name = "dgvCliente";
            this.dgvCliente.Size = new System.Drawing.Size(365, 205);
            this.dgvCliente.TabIndex = 7;
            // 
            // txtCliente
            // 
            this.txtCliente.Location = new System.Drawing.Point(542, 54);
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(100, 20);
            this.txtCliente.TabIndex = 8;
            // 
            // txtCon
            // 
            this.txtCon.Location = new System.Drawing.Point(542, 113);
            this.txtCon.Name = "txtCon";
            this.txtCon.Size = new System.Drawing.Size(100, 20);
            this.txtCon.TabIndex = 9;
            // 
            // btnComfirmar
            // 
            this.btnComfirmar.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnComfirmar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComfirmar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnComfirmar.Location = new System.Drawing.Point(684, 113);
            this.btnComfirmar.Name = "btnComfirmar";
            this.btnComfirmar.Size = new System.Drawing.Size(104, 32);
            this.btnComfirmar.TabIndex = 10;
            this.btnComfirmar.Text = "Comfirmar";
            this.btnComfirmar.UseVisualStyleBackColor = false;
            this.btnComfirmar.Click += new System.EventHandler(this.btnComfirmar_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnComfirmar);
            this.Controls.Add(this.txtCon);
            this.Controls.Add(this.txtCliente);
            this.Controls.Add(this.dgvCliente);
            this.Controls.Add(this.dgvConcessionaria);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCarro);
            this.Controls.Add(this.lblCodigoconcessionaria);
            this.Controls.Add(this.lblCliente);
            this.Controls.Add(this.lblModeloCarro);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.dgvConcessionaria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblModeloCarro;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblCodigoconcessionaria;
        private System.Windows.Forms.Label lblCarro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvConcessionaria;
        private System.Windows.Forms.DataGridView dgvCliente;
        private System.Windows.Forms.TextBox txtCliente;
        private System.Windows.Forms.TextBox txtCon;
        private System.Windows.Forms.Button btnComfirmar;
    }
}